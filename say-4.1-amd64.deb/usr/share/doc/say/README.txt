Package SANREMO: notes
===========================

License: GPL 
Copyright: Michele Andreoli (2006)

The speech system
-------------------

Google text-to-speech TTS, with italian support. 

The SAY utility 
-----------

"say" is perl wrapper utility that add sox audio effects to the
speech system, and more. See: say -h


		Author: Michele Andreoli

Fabula, The Uman Robot
----------------------

A (very old) natural language simulation program, with speech syntesis support.

		Author: Michele Andreoli

